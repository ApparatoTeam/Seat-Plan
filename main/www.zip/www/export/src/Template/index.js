module.exports = {
    BasicReport: require('./BasicReport')
};