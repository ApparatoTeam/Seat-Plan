<?php
echo password_hash('apparato', PASSWORD_BCRYPT);

//class-xxcxcxccxcxcxc
